A Pen created at CodePen.io. You can find this one at https://codepen.io/ariellozam/pen/ErRoZE.

 What is this? This is a prototype for a webapp for making CV the easiest way possible, like a web builder but just for CV, maybe you need to do it in a short time, with a beatiful design, an I'm looking forward to made it printable y diferent formats or publish it on a hosting.